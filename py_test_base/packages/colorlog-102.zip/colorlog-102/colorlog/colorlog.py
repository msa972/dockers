# originally from https://gist.github.com/813057
# Courtesy http://plumberjack.blogspot.com/2010/12/colorizing-logging-output-in-terminals.html
# Tweaked to use colorama for the coloring


"""
Colorize standart logging output

os: Linux, OSX, Windows
dependancies: colorama (http://pypi.python.org/pypi/colorama)
usage:
    import logging
    from colorlog import colorize
    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s')
    logger = logging.getLogger()
    colorize(logger)

    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

"""

import logging
import sys
try:
    import colorama
except ImportError:
    logging.error("Please install colorama: http://pypi.python.org/pypi/colorama")
    colorama = None


def colorize(log):
    ''' colorize_log

    log should be already configured (with basicConfig or with setFormatter).
    '''
    # skip if colorama not found
    if colorama is None:
        return
    colorama.init()
    
    # search for StreamHandlers, and replace them with ColorizingStreamHandlers
    for i, handler in enumerate(log.handlers[:]):
        if isinstance(handler, logging.StreamHandler):
            new_handler = ColorizingStreamHandler()
            formatter = handler.formatter
            new_handler.setFormatter(formatter)
            log.handlers[i] = new_handler


def start():
    print "colorlog is running"


class ColorizingStreamHandler(logging.StreamHandler):
    """ ColorizingStreamHandler
    """

    def __init__(self, stream=None, color_map=None):
        if stream is None:
            stream = sys.stdout
        logging.StreamHandler.__init__(self,
                                       colorama.AnsiToWin32(stream).stream)
        self.color_map = {
            logging.INFO: colorama.Fore.GREEN,
            logging.DEBUG: colorama.Style.DIM + colorama.Fore.CYAN,
            logging.WARNING: colorama.Fore.YELLOW,
            logging.ERROR: colorama.Fore.RED,
            logging.CRITICAL: colorama.Fore.MAGENTA,
        }
        if color_map is not None:
            self.color_map = color_map

    @property
    def is_tty(self):
        isatty = getattr(self.stream, 'isatty', None)
        return isatty and isatty()

    def format(self, record):
        message = logging.StreamHandler.format(self, record)
        #if self.is_tty:
        # Don't colorize a traceback
        parts = message.split('\n', 1)
        parts[0] = self.colorize(parts[0], record)
        message = '\n'.join(parts)
        #message = self.colorize(message, record)
        return message

    def colorize(self, message, record):
        try:
            return (self.color_map[record.levelno] + message +
                    colorama.Style.RESET_ALL)
        except KeyError:
            return message


if __name__ == '__main__':
    logger = logging.getLogger('test')

    handler = ColorizingStreamHandler()
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')
