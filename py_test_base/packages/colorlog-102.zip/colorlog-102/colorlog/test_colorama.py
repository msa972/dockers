import colorama
colorama.init()
print colorama.Fore.GREEN + 'Green'+colorama.Style.RESET_ALL