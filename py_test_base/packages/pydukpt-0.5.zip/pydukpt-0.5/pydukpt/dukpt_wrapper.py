#! /usr/bin/env python  
# -*- coding: latin-1 -*-

## @package security crypto dukpt
#    @file dukpt.py
#    @brief ciphering tools
#    @details definition of methods to cipher and uncipher track
#    @author SPO
#    @version 1.0
#    @date 02/24/2012
#    need to wrappe c++ dukpt library



import os
import dukpt as pydukpt
###import dukptscript
###import dukpttag
import logging
from xml.etree.ElementTree import ElementTree

## @var log
#   Log file : c3genfr.log
if __name__ == "__main__":
    logging.basicConfig()
log = logging.getLogger('dukpt')
log.setLevel(logging.DEBUG)

class Dukpt:
    ## @brief Initialization of class instance
    #    @param self
    #    @return
    def __init__(self, config_file=None, logger=None):
        self.TAG_KEY                = 'key'
        self.TAG_KSN                = 'ksn'
        self.TAG_NB_BIN             = 'nbBin'
        self.TAG_END_PAN_ENC        = 'endPanEnc'
        self.TAG_EXT_ENC            = 'extEnc'
        self.TAG_AMOUNT             = 'amount'
        self.TAG_TPE_ID             = 'tpeId'
        self.TAG_PADDING            = 'padding'
        self.EMPTY = '??????????????????????????????????????' #38 chars
        
        if config_file != None:
            try:                    
                ## @var self.config_file
                #   config_file object : config file of dukpt object
                self._config_file = config_file
                self.tree = ElementTree()
                
                #print 'os.path config_file', os.path.join(os.path.dirname(__file__), config_file )
                self.tree.parse( config_file )
                self._dukpt = self.tree.find("header")
            except IOError as e:    
                print 'cannot open file (%s)' %(config_file)
                raise e
        
            except Exception as e:
                print e
                print 'cannot manage script file', config_file
                raise e
            
            
    def get_dukpt_value(self, name):
        for field in self._dukpt:
            if field.attrib["name"] == name:
                return field.attrib["value"]
        return ""

        
    def cipher_ext(self, iCardData, oCardData, iComputeParam):
        pydukpt.cipher(iCardData, oCardData, iComputeParam)

    def uncipher_ext(self, iCardData, oCardData, iComputeParam):
        pydukpt.uncipher(iCardData, oCardData, iComputeParam)

    def cipher(self, iCardData):
        oCardData = pydukpt.card_data()
        oCardData.iso2 = self.EMPTY
        
        iComputeParam = pydukpt.compute_param()
        iComputeParam.key = self.get_dukpt_value(self.TAG_KEY)
        iComputeParam.ksn = self.get_dukpt_value(self.TAG_KSN)[:20]
        iComputeParam.clearBin = int(self.get_dukpt_value(self.TAG_NB_BIN))
        iComputeParam.endPanEnc = int(self.get_dukpt_value(self.TAG_END_PAN_ENC))
        iComputeParam.padding = self.get_dukpt_value(self.TAG_PADDING)
        iComputeParam.amount = self.get_dukpt_value(self.TAG_AMOUNT)
        iComputeParam.tpeId = self.get_dukpt_value(self.TAG_TPE_ID)
        iComputeParam.extEnc = int(self.get_dukpt_value(self.TAG_EXT_ENC))
        
        
        
        result=self.EMPTY

        pydukpt.cipher( iCardData, oCardData, iComputeParam)
        return oCardData


    def uncipher(self, iCardData):
        oCardData = pydukpt.card_data()
        
        iComputeParam = pydukpt.compute_param()
        iComputeParam.key = self.get_dukpt_value(self.TAG_KEY)
        iComputeParam.ksn = self.get_dukpt_value(self.TAG_KSN)[:20]
        iComputeParam.clearBin = int(self.get_dukpt_value(self.TAG_NB_BIN))
        iComputeParam.endPanEnc = int(self.get_dukpt_value(self.TAG_END_PAN_ENC))
        iComputeParam.padding = self.get_dukpt_value(self.TAG_PADDING)
        iComputeParam.amount = self.get_dukpt_value(self.TAG_AMOUNT)
        iComputeParam.tpeId = self.get_dukpt_value(self.TAG_TPE_ID)
        iComputeParam.extEnc = int(self.get_dukpt_value(self.TAG_EXT_ENC))
        
        
        
        result=self.EMPTY
####        print '--%s--' %iCardData.iso2
####        print '--%s--' %iCardData.pan
####        print '--%s--' %iCardData.cvv
####        print '--%s--' %iCardData.dfv
####        print '--%s--' %iComputeParam.key
####        print '--%s--' %iComputeParam.ksn
####        print '--%d--' %iComputeParam.clearBin
####        print '--%s--' %iComputeParam.extEnc
####        print '--%s--' %iComputeParam.padding
####        print '--%s--' %iComputeParam.amount
####        print '--%s--' %iComputeParam.tpeId

        pydukpt.uncipher( iCardData, oCardData, iComputeParam)
        return oCardData
    
    def cipher_ext_ext(self, iCardData):
        oCardData = pydukpt.card_data_ext()
        oCardData.iso2 = self.EMPTY
        
        iComputeParam = pydukpt.compute_param()
        iComputeParam.key = self.get_dukpt_value(self.TAG_KEY)
        iComputeParam.ksn = self.get_dukpt_value(self.TAG_KSN)[:20]
        iComputeParam.clearBin = int(self.get_dukpt_value(self.TAG_NB_BIN))
        iComputeParam.endPanEnc = int(self.get_dukpt_value(self.TAG_END_PAN_ENC))
        iComputeParam.padding = self.get_dukpt_value(self.TAG_PADDING)
        iComputeParam.amount = self.get_dukpt_value(self.TAG_AMOUNT)
        iComputeParam.tpeId = self.get_dukpt_value(self.TAG_TPE_ID)
        iComputeParam.extEnc = int(self.get_dukpt_value(self.TAG_EXT_ENC))
        
        
        result=self.EMPTY
####        print '--%s--' %iCardData.iso2
####        print '--%s--' %iCardData.pan
####        print '--%s--' %iCardData.cvv
####        print '--%s--' %iCardData.dfv
####        print '--%s--' %iComputeParam.key
####        print '--%s--' %iComputeParam.ksn
####        print '--%d--' %iComputeParam.clearBin
####        print '--%s--' %iComputeParam.extEnc
####        print '--%s--' %iComputeParam.padding
####        print '--%s--' %iComputeParam.amount
####        print '--%s--' %iComputeParam.tpeId

        pydukpt.cipher_ext( iCardData, oCardData, iComputeParam)
        return oCardData
    
    def uncipher_ext_ext(self, iCardData, ksn):
        oCardData = pydukpt.card_data_ext()
        oCardData.iso2 = self.EMPTY
        
        iComputeParam = pydukpt.compute_param()
        iComputeParam.key = self.get_dukpt_value(self.TAG_KEY)
        iComputeParam.ksn = ksn[:20]
        iComputeParam.clearBin = int(self.get_dukpt_value(self.TAG_NB_BIN))
        iComputeParam.endPanEnc = int(self.get_dukpt_value(self.TAG_END_PAN_ENC))
        iComputeParam.padding = self.get_dukpt_value(self.TAG_PADDING)
        iComputeParam.amount = self.get_dukpt_value(self.TAG_AMOUNT)
        iComputeParam.tpeId = self.get_dukpt_value(self.TAG_TPE_ID)
        iComputeParam.extEnc = int(self.get_dukpt_value(self.TAG_EXT_ENC))
        
        
        
        result=self.EMPTY
####        print '--%s--' %iCardData.iso2
####        print '--%s--' %iCardData.pan
####        print '--%s--' %iCardData.cvv
####        print '--%s--' %iCardData.dfv
####        print '--%s--' %iComputeParam.key
####        print '--%s--' %iComputeParam.ksn
####        print '--%d--' %iComputeParam.clearBin
####        print '--%s--' %iComputeParam.extEnc
####        print '--%s--' %iComputeParam.padding
####        print '--%s--' %iComputeParam.amount
####        print '--%s--' %iComputeParam.tpeId

        pydukpt.uncipher_ext( iCardData, oCardData, iComputeParam)
        return oCardData

###
#Methodes de tests avec un fichier de parametre en entree
def test_cipher():
    _dukpt = Dukpt("e2e_data_1.xml")
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413339000001513=1212201000000000000"
    iCardData.pan   = "5413339000001513"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    
    oCardData = _dukpt.cipher(iCardData)
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv

def test_uncipher():
    _dukpt = Dukpt("e2e_data_2.xml")
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413332243292650=1212201916987210153"
    iCardData.pan   = "5413339111503704"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = _dukpt.uncipher(iCardData)
    print 'unciphering iso2 result : %s '%oCardData.iso2
    print 'unciphering pan result  : %s '%oCardData.pan
    print 'unciphering cvv result  : %s '%oCardData.cvv
    print 'unciphering dfv result  : %s '%oCardData.dfv

###
#Methodes de tests avec des parametres passees en arguments
def test_cipher_ext():
    _dukpt = Dukpt()
    
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413339000001513=1212201000000000000"
    iCardData.pan   = "5413339000001513"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = pydukpt.card_data()
    
    iComputeParam = pydukpt.compute_param()    
    iComputeParam.key = "0123456789ABCDEFFEDCBA9876543210"
    iComputeParam.ksn = "FFFF987654000000002C"
    iComputeParam.clearBin = 6
    iComputeParam.endPanEnc = 0
    iComputeParam.extEnc = 0
    iComputeParam.padding = ""
    iComputeParam.amount = "000000"
    iComputeParam.tpeId = ""

    _dukpt.cipher_ext( iCardData, oCardData, iComputeParam)
    
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv

def test_uncipher_ext():
    _dukpt = Dukpt()
    
    iCardData = pydukpt.card_data_ext()
    iCardData.iso1  = "%B5413332324022760^CUST IMP MC 352/^1412205566921488256778871874428163839^E�c"
    iCardData.iso2  = "5413338287364610=14122050699549445772?"
    iCardData.pan   = "5413339438856587"
    iCardData.cvv   = ""
    iCardData.dfv   = "1412"
    iCardData.bIso1 = True
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = pydukpt.card_data_ext()
    
    iComputeParam = pydukpt.compute_param()
    iComputeParam.key = "0123456789ABCDEFFEDCBA9876543210"
    iComputeParam.ksn = "FFFF987654004D600002"
    iComputeParam.clearBin = 6
    iComputeParam.endPanEnc = 0
    iComputeParam.extEnc = 0
    iComputeParam.padding = ""
    iComputeParam.amount = "000000"
    iComputeParam.tpeId = ""
    
    pydukpt.uncipher_ext( iCardData, oCardData, iComputeParam)
    print 'poet'
    print 'unciphering iso1 result : %s '%oCardData.iso1
    print 'unciphering iso2 result : %s '%oCardData.iso2
    print 'unciphering pan result  : %s '%oCardData.pan
    print 'unciphering cvv result  : %s '%oCardData.cvv
    print 'unciphering dfv result  : %s '%oCardData.dfv
 
# Start test


def test_cipher_ext_ext():
    _dukpt = Dukpt("e2e_avis.xml")
    iCardData = pydukpt.card_data_ext()
##    #iCardData.iso2  = "4970100000010006301=1512101???????????"
##    iCardData.iso2  = "4970100000010006301=1512101"
##    iCardData.pan   = "4970100000010006301"
##    iCardData.cvv   = ""
##    iCardData.dfv   = "1512"
##    iCardData.bIso2 = True
##    iCardData.bPan  = True
    iCardData.iso2  = "4970100000010006301=1512101?00000000000"
    iCardData.pan   = "4970100000010006301"
    iCardData.cvv   = ""
    iCardData.dfv   = "1512"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    #oCardData = pydukpt.card_data_ext()
    oCardData = _dukpt.cipher_ext_ext(iCardData)
    
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv
    
    print 'end test'


if __name__ == '__main__':
    #test_cipher()
    #test_uncipher()
    
    #test_cipher_ext()
    #test_uncipher_ext()
    test_cipher_ext_ext()

