# tests for pydukpt library

def test_cipher():
    """
    """
    import pydukpt 
    i_card_data = pydukpt.card_data()
    o_card_data = pydukpt.card_data()
    i_compute_param = pydukpt.compute_param()
    i_compute_param.ksn = "FFFF987654000000002C"
    i_compute_param.key = "0123456789ABCDEFFEDCBA9876543210"
    i_compute_param.clearBin = 6
    i_compute_param.endPanEnc = 0
    i_compute_param.extEnc = False
    i_compute_param.amount ="000000"
    i_card_data.iso2 = "5413339000001513=1212201000000000000"
    i_card_data.bIso2 = True
    i_card_data.pan = "5413339000001513"
    i_card_data.dfv = "1212"
    i_card_data.bPan = True
    pydukpt.cipher( i_card_data, o_card_data, i_compute_param)
    assert o_card_data.iso2 == '5413332243292650=1212201916987210153'
    assert o_card_data.pan == '5413339111503704'
    assert o_card_data.dfv == '1212'
    assert o_card_data.cvv == ''


def test_uncipher():
    """
    """
    import pydukpt 
    i_card_data = pydukpt.card_data()
    o_card_data = pydukpt.card_data()
    i_compute_param = pydukpt.compute_param()
    i_compute_param.ksn = "FFFF987654000000002C"
    i_compute_param.key = "0123456789ABCDEFFEDCBA9876543210"
    i_compute_param.clearBin = 6
    i_compute_param.endPanEnc = 0
    i_compute_param.extEnc = False
    i_compute_param.amount ="000000"
    i_card_data.iso2 = "5413332243292650=1212201916987210153"
    i_card_data.bIso2 = True
    i_card_data.pan = "5413339111503704"
    i_card_data.bPan = True
    i_card_data.dfv = ""
    i_card_data.cvv = ""
    pydukpt.uncipher( i_card_data, o_card_data, i_compute_param)
    assert o_card_data.iso2 == '5413339000001513=1212201000000000000'
    assert o_card_data.pan == '5413339000001513'
    assert o_card_data.dfv == ''
    assert o_card_data.cvv == ''



def test_uncipher_iso1():
    """
    """
    import pydukpt 
    i_card_data = pydukpt.card_data_ext()
    o_card_data = pydukpt.card_data_ext()
    i_compute_param = pydukpt.compute_param()
    i_compute_param.ksn = "FFFF987654004D600002"
    i_compute_param.key = "0123456789ABCDEFFEDCBA9876543210"
    i_compute_param.clearBin = 6
    i_compute_param.endPanEnc = 0
    i_compute_param.extEnc = False
    i_compute_param.amount ="000000"
    i_card_data.iso1 = "%B5413332324022760^CUST IMP MC 352/^1412205566921488256778871874428163839^E\xb2c"
    i_card_data.bIso1 = True
    pydukpt.uncipher_ext( i_card_data, o_card_data, i_compute_param)
    assert o_card_data.iso1 == '%B5413330056003529^CUST IMP MC 352/^1412205990090990010775756142682728924^E\xb2c'

def test_cipher_ext():
    import pydukpt 
    i_card_data = pydukpt.card_data_ext()
    o_card_data = pydukpt.card_data_ext()
    i_compute_param = pydukpt.compute_param()

    i_card_data.pan   = '5413339000001513'
    i_card_data.bPan  = True
    i_card_data.iso2  = '5413339000001513=1212201000000000000'
    i_card_data.bIso2 = True
    i_card_data.cvv   = '535'
    i_card_data.dfv   = '1212'
    i_compute_param.key        = '0123456789ABCDEFFEDCBA9876543210'
    i_compute_param.ksn        = 'FFFF98765400050004CC'
    i_compute_param.clearBin   = 6
    i_compute_param.endPanEnc  = 4
    i_compute_param.padding    = ''
    i_compute_param.amount     = '000000'
    i_compute_param.tpeId      = ''
    i_compute_param.extEnc     = True

    pydukpt.cipher_ext(i_card_data, o_card_data, i_compute_param)

    

if __name__ == "__main__":
    test_cipher()
    test_uncipher()
    test_uncipher_iso1()
    test_cipher_ext()
    print "test ok"
    