#! /usr/bin/env python
# -*- coding: latin-1 -*-

## @tests for security crypto dukpt
#    @file dukpt.py
#    @brief ciphering tools
#    @details definition of methods to cipher and uncipher track
#    @author SPO
#    @version 1.0
#    @date 02/24/2012
#    need to wrappe c++ dukpt library


# todo: add asserts and real wml data to the tests 

import os
import sys

# make sure we take library from source, not the installed one
#sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),"..",)))     

import pydukpt
from pydukpt import Dukpt
import logging

if __name__ == "__main__":
    logging.basicConfig()
log = logging.getLogger('test_dukpt')
log.setLevel(logging.DEBUG)


###
#Methodes de tests avec un fichier de parametre en entree
def test_cipher():
    _dukpt = Dukpt(os.path.join(os.path.dirname(__file__),"e2e_data_1.xml"))
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413339000001513=1212201000000000000"
    iCardData.pan   = "5413339000001513"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True    
    
    oCardData = _dukpt.cipher(iCardData)
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv

def test_uncipher():
    _dukpt = Dukpt(os.path.join(os.path.dirname(__file__),"e2e_data_1.xml"))
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413332243292650=1212201916987210153"
    iCardData.pan   = "5413339111503704"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = _dukpt.uncipher(iCardData)
    print 'unciphering iso2 result : %s '%oCardData.iso2
    print 'unciphering pan result  : %s '%oCardData.pan
    print 'unciphering cvv result  : %s '%oCardData.cvv
    print 'unciphering dfv result  : %s '%oCardData.dfv

###
#Methodes de tests avec des parametres passees en arguments
def test_cipher_ext():
    _dukpt = Dukpt()
    
    iCardData = pydukpt.card_data()
    iCardData.iso2  = "5413339000001513=1212201000000000000"
    iCardData.pan   = "5413339000001513"
    iCardData.cvv   = ""
    iCardData.dfv   = "1212"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = pydukpt.card_data()
    
    iComputeParam = pydukpt.compute_param()    
    iComputeParam.key = "0123456789ABCDEFFEDCBA9876543210"
    iComputeParam.ksn = "FFFF987654000000002C"
    iComputeParam.clearBin = 6
    iComputeParam.endPanEnc = 0
    iComputeParam.extEnc = 0
    iComputeParam.padding = ""
    iComputeParam.amount = "000000"
    iComputeParam.tpeId = ""

    _dukpt.cipher_ext( iCardData, oCardData, iComputeParam)
    
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv

def test_uncipher_ext():
    _dukpt = Dukpt()
    
    iCardData = pydukpt.card_data_ext()
    iCardData.iso1  = "%B5413332324022760^CUST IMP MC 352/^1412205566921488256778871874428163839^E�c"
    iCardData.iso2  = "5413338287364610=14122050699549445772?"
    iCardData.pan   = "5413339438856587"
    iCardData.cvv   = ""
    iCardData.dfv   = "1412"
    iCardData.bIso1 = True
    iCardData.bIso2 = True
    iCardData.bPan  = True
    
    oCardData = pydukpt.card_data_ext()
    
    iComputeParam = pydukpt.compute_param()
    iComputeParam.key = "0123456789ABCDEFFEDCBA9876543210"
    iComputeParam.ksn = "FFFF987654004D600002"
    iComputeParam.clearBin = 6
    iComputeParam.endPanEnc = 0
    iComputeParam.extEnc = 0
    iComputeParam.padding = ""
    iComputeParam.amount = "000000"
    iComputeParam.tpeId = ""
    
    pydukpt.uncipher_ext( iCardData, oCardData, iComputeParam)
    print 'poet'
    print 'unciphering iso1 result : %s '%oCardData.iso1
    print 'unciphering iso2 result : %s '%oCardData.iso2
    print 'unciphering pan result  : %s '%oCardData.pan
    print 'unciphering cvv result  : %s '%oCardData.cvv
    print 'unciphering dfv result  : %s '%oCardData.dfv
 
# Start test


def test_cipher_ext_ext():
    _dukpt = Dukpt(os.path.join(os.path.dirname(__file__),"e2e_avis.xml"))
    iCardData = pydukpt.card_data_ext()
##    #iCardData.iso2  = "4970100000010006301=1512101???????????"
##    iCardData.iso2  = "4970100000010006301=1512101"
##    iCardData.pan   = "4970100000010006301"
##    iCardData.cvv   = ""
##    iCardData.dfv   = "1512"
##    iCardData.bIso2 = True
##    iCardData.bPan  = True
    iCardData.iso2  = "4970100000010006301=1512101?00000000000"
    iCardData.pan   = "4970100000010006301"
    iCardData.cvv   = ""
    iCardData.dfv   = "1512"
    iCardData.bIso2 = True
    iCardData.bPan  = True
    #oCardData = pydukpt.card_data_ext()
    oCardData = _dukpt.cipher_ext_ext(iCardData)
    
    print 'ciphering iso2 result : %s '%oCardData.iso2
    print 'ciphering pan result  : %s '%oCardData.pan
    print 'ciphering cvv result  : %s '%oCardData.cvv
    print 'ciphering dfv result  : %s '%oCardData.dfv
    
    print 'end test'


if __name__ == '__main__':
    test_cipher()
    test_uncipher()    
    test_cipher_ext()
    test_uncipher_ext()
    test_cipher_ext_ext()

